def queue_jump(app) -> None:
    app.jump_queued = True
